<?php
session_start();

echo "<pre>";
print_r($_SESSION);

$usr_email			= $_SESSION['email'];
$usr_id				= $_SESSION['user_id'];
$usr_firstname		= $_SESSION['firstname'];
$usr_lastname		= $_SESSION['lastname'];
$usr_success		= $_SESSION['success'];
$usr_dob			= $_SESSION['dob'];
$usr_gen			= $_SESSION['gen'];
$usr_age			= $_SESSION['age'];
$usr_height			= $_SESSION['height'];
$usr_weight			= $_SESSION['weight'];
$usr_targetweight	= $_SESSION['targetweight'];

?>

<h2>Your Profile Details</h2>

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>
<table class="tg">
<thead>
  <tr>
    <th class="tg-0lax"></th>
    <th class="tg-0lax"></th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
  <tr>
    <td class="tg-0lax"></td>
    <td class="tg-0lax"></td>
  </tr>
</tbody>
</table>